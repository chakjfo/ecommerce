console.log("script.js is running successfully!");
